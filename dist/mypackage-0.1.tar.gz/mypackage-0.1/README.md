# mypackage
This library was created as an example of how to publish your own python library.
## Building this package
'python setup.py sdist'
## installing this package from github
'pip install git+https://github.com/James-Leslie/example-python-package.git'
## updating this package from github
'pip install --upgrade git+https://https://github.com/James-Leslie/example-python-package.git'
